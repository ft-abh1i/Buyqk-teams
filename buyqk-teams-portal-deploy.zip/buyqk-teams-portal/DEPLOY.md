# BuyQK Teams Portal — Vercel Deployment

This package contains only the BuyQK Teams Portal and the shared packages it needs.

## Deploy with GitHub + Vercel

1. Create a new private GitHub repository, for example `buyqk-teams`.
2. Upload the contents of this folder to the repository root.
3. In Vercel, choose **Add New → Project** and import that repository.
4. Keep **Root Directory** set to `./`.
5. The included `vercel.json` already configures:
   - Install command: `npm install`
   - Build command: `npm run build`
   - Output directory: `apps/team-web/dist`
6. Deploy the project.

## Important after deployment

- In Firebase Console, open **Authentication → Settings → Authorized domains** and add the final Vercel domain if Google sign-in reports an unauthorized-domain error.
- Keep the repository private because the source includes internal access-control configuration.
- Review Firebase Authentication, Firestore, Realtime Database, and Storage security rules before sharing the portal publicly.

## Local development

```bash
npm install
npm run dev --workspace=apps/team-web
```

The local development server uses port `3005`.
